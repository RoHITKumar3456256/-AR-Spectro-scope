import { LucideIcon } from "lucide-react";

export interface FeatureItem {
  id: string;
  title: string;
  description: string;
  iconName: string; // Dynamic icon name lookup
}

export interface HowItWorksStep {
  stepNumber: string;
  title: string;
  description: string;
}

export interface PricingPlan {
  name: string;
  priceMonthly: number;
  priceYearly: number;
  period: string;
  description: string;
  features: string[];
  cta: string;
  popular: boolean;
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  company: string;
  text: string;
  avatarUrl: string;
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
}

export interface DemoSample {
  id: string;
  title: string;
  text: string;
  question: string;
}

export interface AnalyzedOutput {
  meetingTitle: string;
  summary: string;
  tasks: Array<{
    assignee: string;
    task: string;
    deadline?: string;
  }>;
  decisions: string[];
  offlineMode?: boolean;
}
