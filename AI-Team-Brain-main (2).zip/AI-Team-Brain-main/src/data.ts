import { FeatureItem, HowItWorksStep, PricingPlan, TestimonialItem, FaqItem, DemoSample } from "./types";

export const FEATURES: FeatureItem[] = [
  {
    id: "feat-1",
    title: "AI Meeting Summaries",
    description: "Convert long meetings into concise summaries in seconds. Focus on the discussion, not on writing down minutes.",
    iconName: "FileText"
  },
  {
    id: "feat-2",
    title: "Action Item Extraction",
    description: "Automatically identify tasks, owners, and explicit or implicit deadlines from transcripts, chat conversations, and meetings.",
    iconName: "CheckSquare"
  },
  {
    id: "feat-3",
    title: "AI Team Knowledge Base",
    description: "Store and index all team conversations in a central hub. Find answers across multiple past meetings in milliseconds.",
    iconName: "Database"
  },
  {
    id: "feat-4",
    title: "Ask AI Anything",
    description: "Ask questions about previous meetings and get instant, grounded answers. It's like having an infinite memory of past alignments.",
    iconName: "HelpCircle"
  },
  {
    id: "feat-5",
    title: "Daily Reports",
    description: "Generate automated daily updates, summaries of blockers, and current team progress reports directly shared to internal portals.",
    iconName: "Award"
  },
  {
    id: "feat-6",
    title: "Decision Tracking",
    description: "Log and label key architectural, roadmap, and company decisions automatically. Never experience 'what did we agree on?' again.",
    iconName: "ShieldAlert"
  }
];

export const STEPS: HowItWorksStep[] = [
  {
    stepNumber: "01",
    title: "Upload Meeting Notes",
    description: "Drag-drop any audio file, copy-paste a meeting transcript, or let our bots stream directly from Zoom, Google Meet, or Slack."
  },
  {
    stepNumber: "02",
    title: "AI Analyzes Content",
    description: "Our platform processes the raw transcript, filters voice filler words, extracts speakers, and identifies semantic context."
  },
  {
    stepNumber: "03",
    title: "Summary & Tasks Generated",
    description: "In seconds, a executive summary, categorized action items table, and definitive decision timelines are published."
  },
  {
    stepNumber: "04",
    title: "Knowledge Base Storage",
    description: "Information gets automatically indexed in a secure vector database, mapping dependencies across teams and projects."
  },
  {
    stepNumber: "05",
    title: "Ask Questions Anytime",
    description: "Query your team's cumulative knowledge. Ask 'Who tested the API?' or 'Why did we reject the alternative server architecture?'"
  }
];

export const BENEFITS = [
  {
    id: "ben-1",
    value: "10+ Hours",
    label: "Saved Every Week",
    description: "Eliminate manual writing, note compiling, and post-meeting Slack recaps entirely."
  },
  {
    id: "ben-2",
    value: "99%",
    label: "Reduction in Missed Tasks",
    description: "Auto-extracted tasks sync directly into Slack, Jira, or GitHub issues so nothing falls behind."
  },
  {
    id: "ben-3",
    value: "100%",
    label: "Improved Team Alignment",
    description: "Remote team members catch up on 60-minute meetings in 45 seconds with perfect clarity."
  },
  {
    id: "ben-4",
    value: "Single",
    label: "Source of Truth",
    description: "Every verbal agreement, roadmap pivot, and security sign-off documented and indexed forever."
  },
  {
    id: "ben-5",
    value: "1.5x",
    label: "Increase in Productivity",
    description: "Fewer sync meetings, zero redundant alignment syncs, and pure execution velocity."
  }
];

export const PRICING_PLANS: PricingPlan[] = [
  {
    name: "Starter",
    priceMonthly: 0,
    priceYearly: 0,
    period: "month",
    description: "Perfect for individuals and small startups looking to secure basic meeting memory.",
    features: [
      "5 meetings analyzed per month",
      "Executive AI summaries",
      "Action items extraction",
      "Web interface access only",
      "Standard vector indexing (30 days)"
    ],
    cta: "Start Free Now",
    popular: false
  },
  {
    name: "Pro",
    priceMonthly: 19,
    priceYearly: 15,
    period: "month",
    description: "Accelerate alignment for fast-paced remote teams needing full cross-topic memory.",
    features: [
      "Unlimited meetings analyzed",
      "Full RAG knowledge base search",
      "Interactive QA AI chatbot helper",
      "Direct Slack & email alerts",
      "Priority fast processing lane",
      "Unlimited historic storage"
    ],
    cta: "Get Started Pro",
    popular: true
  },
  {
    name: "Team",
    priceMonthly: 49,
    priceYearly: 39,
    period: "month",
    description: "Enterprise scalability with custom security controls for cross-department synergy.",
    features: [
      "Everything in Pro tier included",
      "Dedicated team workspaces & roles",
      "Zoom & Google Meet integration bots",
      "Jira, GitHub, and Notion syncs",
      "Custom security and SOC2 safeguards",
      "SLA support & training portal"
    ],
    cta: "Deploy Team Enterprise",
    popular: false
  }
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: "test-1",
    name: "Marcus Aurelius",
    role: "Engineering Manager",
    company: "Centurion Technologies",
    text: "AI Team Brain completely rewired how our engineering pod handles standups. I can confidently skip a 45-minute sync, read the generated checklist in 30 seconds, and know who is unblocked.",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80"
  },
  {
    id: "test-2",
    name: "Priya Patel",
    role: "Director of Product",
    company: "Svelte Labs",
    text: "We had a habit of losing pivotal decisions on Slack. Now, our transcripts are vector-stored. Asking the chat assistant 'why did we pivot the database strategy' gives the exact transcript quote in seconds.",
    avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80"
  },
  {
    id: "test-3",
    name: "Aman Deshmukh",
    role: "VP of Remote Success",
    company: "Aether Grid",
    text: "With a distributed crew across 4 continents, scheduling review meetings was painful. Now we record, upload to AI Team Brain, and let it construct our beautiful daily bulletins automatically.",
    avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80"
  }
];

export const FAQS: FaqItem[] = [
  {
    id: "faq-1",
    question: "How does AI Team Brain work?",
    answer: "AI Team Brain captures audio, video, or raw text transcripts of your discussions. In the cloud, our systems parse, analyze, and extract main conversational pillars. It structures summaries, tags action items to task holders, logs main design decisions, and stores this parsed context in a vector database for natural-language Q&A."
  },
  {
    id: "faq-2",
    question: "What file formats are supported?",
    answer: "We support video formats (MP4, MOV, WebM), audio tracks (MP3, WAV, M4A), raw markdown/text pastes, and direct copy-pasted Zoom/Meet auto-generated captions."
  },
  {
    id: "faq-3",
    question: "Can it analyze Slack conversations?",
    answer: "Yes! Connecting our Slack Integration auto-indexes specified status rooms. When a hot thread closes, AI Team Brain tags and logs the final consensus, storing it in your company's semantic knowledge library."
  },
  {
    id: "faq-4",
    question: "How secure is my company's data?",
    answer: "Data privacy is our baseline. All customer transcripts are isolated, encrypted at rest and in transit via TLS 1.3, and never used to fine-tune public baseline AI models. We follow strict SOC2 guidelines and support self-hosted/private cloud database deployments for Team partners."
  },
  {
    id: "faq-5",
    question: "Can I connect Zoom or Google Meet directly?",
    answer: "Absolutely. With our Pro and Team integrations, you can activate the 'AI Team Brain Bot' to securely join your Zoom, Google Meet, or Microsoft Teams calls, record audio streams, and output your digest automatically right after the call ends."
  }
];

export const DEMO_SAMPLES: DemoSample[] = [
  {
    id: "sprint-sync",
    title: "Sprint Prep Sync (Rohit & Aman)",
    text: "Rohit will build login page. Aman will test APIs. Deployment scheduled for Friday.",
    question: "Who is responsible for testing?"
  },
  {
    id: "redesign-brainstorm",
    title: "Landing Layout Redesign (Sophia & Liam)",
    text: "Sophia will build interactive wireframes and custom UI components by Friday night. Liam is drafting final website copywriting and pricing taglines by Sunday afternoon. The team schedule has a final design system review on next Monday.",
    question: "When is the team reviewing the design system?"
  }
];
